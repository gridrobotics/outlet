package com.outlet;

import java.util.ArrayList;
import java.util.List;
import java.nio.file.Files;
import java.nio.file.Paths;

public class OutletPages {
	
	 public static String readFileAsString(String fileName)throws Exception
	    {
	        String data = "";
	        data = new String(Files.readAllBytes(Paths.get(fileName)));
	        return data;
	    }

	    public static void main(String[] args) throws Exception
	    {
	        String data = readFileAsString("E:\\outlet\\OutletHome.txt");
	        // if mac OS than it should be readFileAsString("/Users/***/OutletHome.txt");
	        String[] splittedString = data.split("href=");

	        List<String> outputList = new ArrayList<>();

	        for(int i=0; i<splittedString.length;i++){
	            if(splittedString[i].indexOf("/outlet/") == 1) {
	                String outputString ="https://www.webstaurantstore.com"+splittedString[i].substring(1,splittedString[i].indexOf(".html")+5);
	             //   System.out.println(outputString);
	               // System.out.println("*********");
	                outputList.add(outputString);
	            }
	        }
                System.out.println(outputList);
	    }

}
