I started out by writing a java app that extracted all the products from the home page to generate a CSV file that I could select from randomly but there would only be a single request in the thread loop and it would not be obvious in the report which page was which. So I randomly selected a few from the list instead.

Randy